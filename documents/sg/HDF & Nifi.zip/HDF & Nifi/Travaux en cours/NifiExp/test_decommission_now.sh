#!/bin/bash

echo "Demande de token"
TOKEN="$(/root/curl/bin/curl -u admin:PVlrZV2iB4J1  -k -d "username=admin&password=PVlrZV2iB4J1" -X  POST https://inbdfte02.rouen.francetelecom.fr:9091/nifi-api/access/token)"
echo $TOKEN
echo "Deconnexion du Noeud"
sleep 3 
echo "/root/curl/bin/curl -k  -H "Content-Type: application/json" -d '{"node":{"nodeId":"9116d192-184e-4538-9986-0dc68a04c119","status":"DISCONNECTING"}}' -X PUT  https://inbdfte02.rouen.francetelecom.fr:9091/nifi-api/controller/cluster/nodes/9116d192-184e-4538-9986-0dc68a04c119 -H 'Authorization: Bearer $TOKEN'"
/root/curl/bin/curl -k  -H "Content-Type: application/json" -d '{"node":{"nodeId":"9116d192-184e-4538-9986-0dc68a04c119","status":"DISCONNECTING"}}' -X PUT  https://inbdfte02.rouen.francetelecom.fr:9091/nifi-api/controller/cluster/nodes/9116d192-184e-4538-9986-0dc68a04c119 -H 'Authorization: Bearer "'"$TOKEN"'"'


