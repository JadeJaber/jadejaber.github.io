#!/bin/ksh

#COLOUR
# ------------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

#### VARIABLES #####
ADMIN="admin"
ADMIN_PASS="PVlrZV2iB4J1"
CURL_PATH="/root/curl/bin"
#inbdfte02
NODE_ID_DISCONNECT="9116d192-184e-4538-9986-0dc68a04c119" 
#inbdfte03
#NODE_ID_DISCONNECT="63b41fe5-3120-48d1-94ae-f7751dd02faf" 
PRIMARY_NODE_FQDN="inbdfte03.rouen.francetelecom.fr"
NODE_FQDN_DISCONNECT="inbdfte02.rouen.francetelecom.fr"



python nifi-client-python.py  https://$NODE_FQDN_DISCONNECT:9091/nifi-api  stop-input-processors admin  $ADMIN_PASS

echo "\n0. Demande de token pour communiquer avec l API de Nifi"
TOKEN="$($CURL_PATH/curl -k -s -d "username=$ADMIN&password=$ADMIN_PASS" -X  POST https://$NODE_FQDN_DISCONNECT:9091/nifi-api/access/token)"


echo "\n1. Deconnexion du noeud Nifi du cluster"
DISCONNECT="$($CURL_PATH/curl -s  -k -H 'Content-Type: application/json' -d '{"node":{"nodeId":"'$NODE_ID_DISCONNECT'","status":"DISCONNECTING"}}' -X PUT  https://$NODE_FQDN_DISCONNECT:9091/nifi-api/controller/cluster/nodes/$NODE_ID_DISCONNECT -H 'Authorization: Bearer '$TOKEN)"
echo "\n${GREEN}   Noeud deconnecte du cluster avec succes\n${NC}"

echo "2. Interrogation du nombre de FlowFile en cours de traitement sur le noeud\n"
JSRESP="$($CURL_PATH/curl -k -s  -X GET https://$NODE_FQDN_DISCONNECT:9091/nifi-api/flow/status -H 'Authorization: Bearer '$TOKEN)"
FF_COUNT=$(echo  $JSRESP > temp.json && echo -e "temp.json\n" | awk  -f ./JSON.awk | grep queued | awk -F '[]/"]' '{ print $7 }')
while ( [ $FF_COUNT -gt 0 ] && [ $SECONDS -lt 15 ] )
do
	FF_COUNT_OLD="$FF_COUNT"
	JSRESP="$($CURL_PATH/curl -k -s  -X GET https://$NODE_FQDN_DISCONNECT:9091/nifi-api/flow/status -H 'Authorization: Bearer '$TOKEN)"
	FF_COUNT=$(echo  $JSRESP > temp.json && echo -e "temp.json\n" | awk  -f ./JSON.awk | grep queued | awk -F '[]/"]' '{ print $7 }')
	if [ $FF_COUNT -lt $FF_COUNT_OLD ]; then SECONDS=0; fi
	echo " -En attente du traitement de l ensemble des donnees en transit sur ce noeud. Il reste actuellement ${RED}$FF_COUNT${NC}FlowFile en cours de traitement\n"
	sleep 1
done

#TODO : Recuperer le primary Node pour pouvoir supprimer le noeud Nifi du cluster


if  [ $FF_COUNT -eq 0 ]; then  
	echo "3. Supression du noeud du cluster\n"
        TOKEN_PRIMARY="$($CURL_PATH/curl -k -s -d "username=$ADMIN&password=$ADMIN_PASS" -X  POST https://$PRIMARY_NODE_FQDN:9091/nifi-api/access/token)"
	$CURL_PATH/curl -k -s  -X DELETE https://$PRIMARY_NODE_FQDN:9091/nifi-api/controller/cluster/nodes/$NODE_ID_DISCONNECT -H 'Authorization: Bearer '$TOKEN_PRIMARY
	echo "\n${GREEN}   Noeud supprime du cluster avec succes\n${NC}"
else	
	echo "${RED} -TIMEOUT : Le noeud n arrive pas a traiter les FlowFile en cours de traitement. L arret du cluster n est donc pas possible. Il faut voir pourquoi les FlowFiles ne sont pas traités${NC} "
fi


