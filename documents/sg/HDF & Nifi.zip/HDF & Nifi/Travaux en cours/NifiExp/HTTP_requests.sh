#!/bin/bash

for i in {1..10000}
do
curl  -k -X POST -d "$i" http://inbdfte02.rouen.francetelecom.fr:3000  --header "Content-Type:text/xml" > /dev/null 2>&1
  if  [ $? != 0 ]
        then
                curl -s -X POST -k -d "$i" http://inbdfte03rouen.francetelecom.fr:3000  --header "Content-Type:text/xml" > /dev/null 2>&1
                echo "Envoyé $i à inbfte03"
        else
                echo "Envoyé $i à inbfte02"
  fi
sleep 0.1
done

